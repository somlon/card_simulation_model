@echo off
chcp 65001 > nul
cd /d "%~dp0"
"runtime\python.exe" -I -X utf8 "app\main.py" %*
pause
